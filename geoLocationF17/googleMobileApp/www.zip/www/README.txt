Default empty PhoneGap Template for CIS 430

(version 2.9, April 9th, 2017)

.
├── hooks
│   └── README.md
├── platforms
│   ├── browser
│   └── platforms.json
├── plugins
│   ├── browser.json
│   ├── cordova-plugin-battery-status
│   ├── cordova-plugin-camera
│   ├── cordova-plugin-compat
│   ├── cordova-plugin-console
│   ├── cordova-plugin-contacts
│   ├── cordova-plugin-device
│   ├── cordova-plugin-device-motion
│   ├── cordova-plugin-device-orientation
│   ├── cordova-plugin-dialogs
│   ├── cordova-plugin-file
│   ├── cordova-plugin-file-transfer
│   ├── cordova-plugin-geolocation
│   ├── cordova-plugin-globalization
│   ├── cordova-plugin-inappbrowser
│   ├── cordova-plugin-media
│   ├── cordova-plugin-media-capture
│   ├── cordova-plugin-network-information
│   ├── cordova-plugin-splashscreen
│   ├── cordova-plugin-statusbar
│   ├── cordova-plugin-vibration
│   ├── cordova-plugin-whitelist
│   └── fetch.json
└── www						: zip this folder and upload to build.phonegap.com
    ├── config.xml			: update for your config and plugins
    ├── css 				: place your css files here
    │   └── index.css 		:   default css file
    ├── img 				: place any images here
    ├── index.html 			: staring point for your mobile app
    ├── js 					: place your JavaScript here
    │   └── index.js 		:  default JavaScript file
    └── res 				: Location of default splash screens and icons
        ├── icon
        └── screen

